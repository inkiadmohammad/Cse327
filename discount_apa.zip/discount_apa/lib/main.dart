import 'package:discount_apa/app/sign_in/landing_page.dart';
import 'package:flutter/material.dart';


vaid main (){
  runApp(Myapp());
}

class Myapp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'time tracker',
      theme: ThemeData(
        primarySwatch: Colors.indigo,
      ),
      home: landing_page_c(),
    );
  }

}
