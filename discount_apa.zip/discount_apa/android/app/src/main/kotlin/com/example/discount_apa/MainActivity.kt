package com.example.discount_apa

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
